from FEM import FEM 

FILE_PATH='Dogbone_Tension.txt'
plot_type='all'

s=FEM()

s.fem2d(FILE_PATH,plot_type)


